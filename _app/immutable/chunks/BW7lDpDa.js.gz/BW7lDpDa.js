import{o as a}from"./CDoyrOs-.js";a();
