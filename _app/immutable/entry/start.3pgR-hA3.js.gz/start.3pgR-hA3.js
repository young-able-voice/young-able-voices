import{l as o,a as r}from"../chunks/Dy3jV7bo.js";export{o as load_css,r as start};
